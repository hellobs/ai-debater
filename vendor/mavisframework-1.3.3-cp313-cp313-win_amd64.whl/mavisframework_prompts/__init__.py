# prompt templates shipped alongside the compiled wheel
